export const EIP1967_IMPLEMENTATION_SLOT='0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc';
export const EIP1967_ADMIN_SLOT='0xb53127684a568b3173ae13b9f8a6016e019b9b0f6f6e8f5b1d1a0f3a5e6f1b2';
export function isEvmAddress(v:string){return /^0x[a-fA-F0-9]{40}$/.test(v)}
export function isTxHash(v:string){return /^0x[a-fA-F0-9]{64}$/.test(v)}
export function hexToBigInt(v:string){return BigInt(v)}
