import React,{useState} from "react";
import {createRoot} from "react-dom/client";
import {Wallet,LayoutDashboard,Search,Code2,Coins,Database,Gamepad2,CreditCard,Shield,Menu,X,Send,Activity,ArrowLeftRight,Gift,Network,Copy,CheckCircle2} from "lucide-react";
import "./styles.css";

const items=[
["Dashboard",LayoutDashboard],["Wallet",Wallet],["Bridge & Swap",ArrowLeftRight],
["Transaction Intelligence",Search],["Smart Contract Center",Code2],["OSTAD Token Studio",Coins],
["Liquidity & Pools",Database],["Payment Hub",CreditCard],["Telegram Game Hub",Gamepad2],
["Rewards",Gift],["Security",Shield]
];

function App(){
 const [page,setPage]=useState("Dashboard"),[menu,setMenu]=useState(false),[wallet,setWallet]=useState("");
 const [hash,setHash]=useState(""),[network,setNetwork]=useState("auto"),[notice,setNotice]=useState("");
 const connect=()=>{setWallet("0x71...8A42");setNotice("Wallet connection simulated — replace with injected provider in production.")};
 const scan=()=>{if(!hash){setNotice("Enter a transaction hash first.");return}setNotice("Scanner ready: connect an RPC/indexer to resolve this hash.")};
 const broadcast=()=>{if(!hash){setNotice("Paste a signed/raw transaction first.");return}setNotice("Broadcast pipeline ready. Never enter a private key or seed phrase.")};
 return <div className="app">
  <aside className={menu?"side open":"side"}>
   <div className="brand"><div className="seal">𓂀</div><div><b>OSTAD</b><small>SUPER PLATFORM</small></div></div>
   <nav>{items.map(([n,I])=><button className={page===n?"nav active":"nav"} onClick={()=>{setPage(n);setMenu(false)}}><I size={17}/>{n}</button>)}</nav>
   <div className="safe">NON-CUSTODIAL • SECURITY FIRST</div>
  </aside>
  {menu&&<button className="overlay" onClick={()=>setMenu(false)}><X/></button>}
  <main>
   <header><button className="hamb" onClick={()=>setMenu(true)}><Menu/></button><span className="crumb">OSTAD / {page.toUpperCase()}</span><button className="connect" onClick={connect}><Wallet size={16}/>{wallet||"CONNECT WALLET"}</button></header>
   {notice&&<div className="notice"><CheckCircle2 size={16}/>{notice}</div>}
   {page==="Dashboard"&&<Dashboard setPage={setPage}/>}
   {page==="Transaction Intelligence"&&<Scanner hash={hash} setHash={setHash} network={network} setNetwork={setNetwork} scan={scan} broadcast={broadcast}/>}
   {page!=="Dashboard"&&page!=="Transaction Intelligence"&&<Module title={page}/>}
   <footer><span>OSTAD • Web3 • Smart Contracts • Payments • Games</span><strong>Built by Eng. Alireza Ostadzadeh</strong></footer>
  </main>
 </div>
}
function Dashboard({setPage}:{setPage:(x:string)=>void}){return <><section className="hero"><div className="seal big">𓂀</div><p className="eyebrow">ADVANCED WEB3 COMMAND CENTER</p><h1>OSTAD <span>SUPER PLATFORM</span></h1><p>Wallets, smart contracts, transactions, liquidity, payments and Telegram games in one command center.</p><div className="actions"><button className="primary"><Wallet/> Connect Wallet</button><button className="secondary" onClick={()=>setPage("Transaction Intelligence")}><Search/> Scan & Broadcast</button></div></section><section className="cards">{[
["Wallet","Connect • Assets • Send • Receive",Wallet],["Smart Contracts","Proxy • UUPS • ABI • Events",Code2],["OSTAD Token","Mint • Burn • Supply • Access",Coins],["Liquidity","Pools • LP • TVL • Treasury",Database],["Payments","Gateway • Invoice • Settlement",CreditCard],["Telegram Games","Arena • Puzzle • Quiz • Kingdom",Gamepad2]
].map(([t,d,I])=><article className="card"><I className="gold"/><div><b>{t}</b><p>{d}</p></div></article>)}</section></>}
function Scanner({hash,setHash,network,setNetwork,scan,broadcast}:{hash:string,setHash:(x:string)=>void,network:string,setNetwork:(x:string)=>void,scan:()=>void,broadcast:()=>void}){return <section className="workspace"><div className="title"><p className="eyebrow">TRANSACTION INTELLIGENCE</p><h1>Scan & Broadcast</h1><p>Analyze a transaction hash or broadcast an already signed transaction. Private keys and seed phrases never belong in this interface.</p></div><div className="panel"><label>Transaction Hash / Signed Raw Transaction</label><textarea value={hash} onChange={e=>setHash(e.target.value)} placeholder="0x..."/><div className="row"><select value={network} onChange={e=>setNetwork(e.target.value)}><option value="auto">Auto-detect network</option><option>Ethereum</option><option>BNB Smart Chain</option><option>Polygon</option><option>Base</option><option>Arbitrum</option><option>Optimism</option></select><button className="primary" onClick={scan}><Search/> Scan</button><button className="secondary" onClick={broadcast}><Send/> Broadcast</button></div></div><div className="grid3"><Info title="Decoder" text="From / To / Value / Input / Logs"/><Info title="Tracking" text="Pending → Confirmed → Failed"/><Info title="Explorer" text="Network-specific explorer link"/></div></section>}
function Info({title,text}:{title:string,text:string}){return <div className="mini"><Activity size={18}/><b>{title}</b><span>{text}</span></div>}

function ContractCenter(){
 const [address,setAddress]=useState(""),[network,setNetwork]=useState("Ethereum"),[abi,setAbi]=useState(""),[status,setStatus]=useState("");
 const scan=()=>{if(!/^0x[a-fA-F0-9]{40}$/.test(address)){setStatus("Enter a valid EVM contract address.");return}setStatus("Address validated. Connect an RPC/indexer to inspect bytecode, proxy slots and verified ABI.");};
 const decode=()=>{if(!abi){setStatus("Paste ABI JSON first.");return}try{JSON.parse(abi);setStatus("ABI JSON is valid and ready for Read/Write tooling.");}catch{setStatus("ABI JSON is not valid.");}};
 return <section className="workspace">
  <p className="eyebrow">SMART CONTRACT CENTER</p><h1>Contract Scanner</h1>
  <p className="sub">Inspect EVM contracts, proxy patterns, ABI, calldata and events from one controlled workspace.</p>
  <div className="contractTop">
   <input value={address} onChange={e=>setAddress(e.target.value)} placeholder="0x Contract Address"/>
   <select value={network} onChange={e=>setNetwork(e.target.value)}><option>Ethereum</option><option>BNB Smart Chain</option><option>Polygon</option><option>Base</option><option>Arbitrum</option><option>Optimism</option></select>
   <button className="primary" onClick={scan}><Search/> Scan Contract</button>
  </div>
  {status&&<div className="result">{status}</div>}
  <div className="contractGrid">
   <div className="panel"><Code2 className="gold"/><h2>Proxy / UUPS</h2><p>Architecture for implementation detection, EIP-1967 slots and UUPS inspection.</p><div className="checks"><span>V1 / V2</span><span>Implementation</span><span>Admin / Owner</span><span>Pause</span></div></div>
   <div className="panel"><Zap className="gold"/><h2>ABI & Calldata</h2><textarea value={abi} onChange={e=>setAbi(e.target.value)} placeholder='Paste Custom ABI JSON...'/><button className="secondary" onClick={decode}>Validate ABI</button></div>
   <div className="panel"><Activity className="gold"/><h2>Events</h2><p>Event selector search, block-range filtering and decoded logs are wired as the next RPC/indexer layer.</p><div className="checks"><span>From Block</span><span>To Block</span><span>Topics</span></div></div>
  </div>
  <div className="panel"><h2>Read / Write Contract</h2><p>After ABI resolution, functions are presented with typed inputs, read results, wallet confirmation for writes, gas estimation and transaction tracking.</p></div>
 </section>
}

function Module({title}:{title:string}){return <section className="workspace"><p className="eyebrow">OSTAD MODULE</p><h1>{title}</h1><div className="panel"><Network size={28}/><h2>Production module scaffold</h2><p>This module is wired into the unified OSTAD navigation. Real providers, RPC endpoints, contracts and secure backend services are added in the integration phase.</p><div className="checks"><span>✓ Responsive UI</span><span>✓ Security boundary</span><span>✓ Multi-chain ready</span><span>✓ API integration point</span></div></div></section>}
createRoot(document.getElementById("root")!).render(<App/>);
