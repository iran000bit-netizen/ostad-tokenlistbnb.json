export const EVM_NETWORKS={ethereum:{chainId:'0x1',name:'Ethereum'},bnb:{chainId:'0x38',name:'BNB Smart Chain'},polygon:{chainId:'0x89',name:'Polygon'},base:{chainId:'0x2105',name:'Base'},arbitrum:{chainId:'0xa4b1',name:'Arbitrum'}} as const;
export async function requestChainSwitch(provider:any,chainId:string){return provider.request({method:'wallet_switchEthereumChain',params:[{chainId}]})}
export async function getLatestBlock(provider:any){return provider.request({method:'eth_blockNumber'})}
