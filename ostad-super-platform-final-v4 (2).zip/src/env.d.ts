interface Window { ethereum?: any }
